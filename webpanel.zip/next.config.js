module.exports = {
  images: {
    domains: ['img1.pixhost.to'],
  },
};
